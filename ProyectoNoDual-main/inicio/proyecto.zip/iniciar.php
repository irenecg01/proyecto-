<?php
$correo=$_GET["correo"];
$usuario=$_GET["usuario"];
$contrasena=$_GET["contrasena"];
try{
      include("conexion.php");
    $sql = "SELECT * FROM login WHERE usuario=:usuario OR correo=:correo AND contrasena=:contrasena";
    $resultado=$base->prepare($sql);
    $login=htmlentities(addslashes($_GET['usuario']));
    $login=htmlentities(addslashes($_GET['correo']));
    $password=htmlentities(addslashes($_GET['contrasena']));
    $resultado->bindValue(":usuario",$usuario);
    $resultado->bindValue(":contrasena",$contrasena);
    $resultado->bindValue(":correo",$correo);
    $resultado->execute();
     $numero_registro=$resultado->rowCount();
    if ($numero_registro!=0) {
          echo "<h2>Adelante!!</h2>";
          } else {
               header("location:index.html");
          }
          }catch(Exception $e){
              die("Error: " . $e->getMessage());
          }
          ?>